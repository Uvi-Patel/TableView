//
//  ViewController.swift
//  TableView_demo
//
//  Created by MAC on 02/06/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
   // let screeWidth = UIScreen.main.bounds.size.width
    //let screenHeight = UIScreen.main.bounds.size.height
    
    @IBOutlet weak var animalTableView: UITableView!
    
    @IBOutlet weak var LabelCell: UILabel!
    var animals: NSMutableArray = ["Cat","Dog","Lion","Tiger","Elephant","Cow"]
    var alpabet = ["A","B","C","D","E","F","G","H","I","J","K"]
    var number = ["0","1","2","3","4","5","6","7","8","9"]

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tb1 = UINib(nibName: "table_cell", bundle: nil)
        //tb1.register(UINib(nibName: "CustomCell", bundle: nil), forCellReuseIdentifier: "CustomCell")

        animalTableView.delegate = self
        animalTableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        print("numberOfsection")
        return 3
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("didSelectRowAt")
        print("indexpath \(indexPath)")
        print("row \(indexPath.row)")
        if indexPath.section == 0
        {
        print("selected \(animals[indexPath.row])")
        }
        else if indexPath.section == 1
        {
        print("selected \(alpabet[indexPath.row])")
        }
        else
        {
        print("selected \(number[indexPath.row])")
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("numberOfRowsInSection")
        if section == 0
        {
            return animals.count
        }
        else if section == 1
        {
            return alpabet.count
        }
        else
        {
            return number.count
        }

    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        print("cellForRowAt")
        
        let cell = animalTableView.dequeueReusableCell(withIdentifier: "animalCell", for: indexPath) as! MyCustomTableViewCell
        cell.selectionStyle = .none
        let rowBTN = UIButton()
        rowBTN.frame = CGRect(x: 170, y: 10, width: 100, height: 30)
        rowBTN.setTitle("Btn", for: .normal)
        rowBTN.backgroundColor = UIColor.white
       
        rowBTN.setTitleColor(UIColor.black, for: .normal)
        rowBTN.tag = indexPath.row
        rowBTN.addTarget(self, action: #selector(clickOnBtn), for: .touchUpInside)
        cell.addSubview(rowBTN)
        cell.accessoryType = UITableViewCell.AccessoryType.detailButton
        if indexPath.section == 0
        {
            cell.LabelCell.text = animals[indexPath.row] as? String
        }
        else if indexPath.section == 1
        {
            cell.LabelCell.text = alpabet[indexPath.row]
        }
        else
        {
            cell.LabelCell.text = number[indexPath.row]
        }
        cell.LabelCell.font = UIFont.italicSystemFont(ofSize: 20)
//        cell.LabelCell.font = UIFont.boldSystemFont(ofSize: 15)
        cell.LabelCell.textColor = UIColor.white
        //cell.LabelCell.textAlignment = .center
        cell.imageVIEW.layer.cornerRadius = cell.imageVIEW.frame.size.width / 2
        cell.imageVIEW.layer.borderWidth = 2
        cell.imageVIEW.layer.borderColor = UIColor.black.cgColor
        //cell.backgroundColor = UIColor.gray
        if indexPath.row % 4 == 0 {
            cell.backgroundColor = UIColor.systemPink
        }
        else {
            cell.backgroundColor = UIColor.gray
        }
        
        
        //cell.textLabel?.backgroundColor = UIColor.yellow
        return cell
        
    }
    
    
   func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
     let insertaction = UITableViewRowAction(style: .default, title: "Insert", handler: { (action, indexPath) in
                let alert = UIAlertController(title: "", message: "Insert list item", preferredStyle: .alert)
                alert.addTextField(configurationHandler: { (textField) in
                })
                alert.addAction(UIAlertAction(title: "Insert", style: .default, handler: { (insertAction) in
                    let firstTextField = alert.textFields![0] as UITextField

                    self.animals.add(firstTextField.text)
                    tableView.reloadData()
                }))
                alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(alert, animated: false)
    })
    
    let editAction = UITableViewRowAction(style: .default, title: "Edit", handler: { (action, indexPath) in
              let alert = UIAlertController(title: "", message: "Edit list item", preferredStyle: .alert)
              alert.addTextField(configurationHandler: { (textField) in
                textField.text = self.animals[indexPath.row] as! String
              })
              alert.addAction(UIAlertAction(title: "Update", style: .default, handler: { (updateAction) in
                  self.animals[indexPath.row] = alert.textFields!.first!.text!
                  tableView.reloadRows(at: [indexPath], with: .fade)
              }))
              alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
              self.present(alert, animated: false)
    })
    editAction.backgroundColor = UIColor.blue
    
    let deleteAction = UITableViewRowAction(style: .default, title: "Delete", handler: { (action, indexPath) in
        self.animals.remove(indexPath.row)
              tableView.reloadData()
    })

    return [deleteAction, editAction, insertaction]
   }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        print("willDisplayHeaderView ")
    }
    func tableView(_ tableView: UITableView, willDisplayFooterView view: UIView, forSection section: Int) {
        print("willDisplayFooterView ")
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath)
    {
        print("willDisplay cell")
    }
    func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        print("didEndDisplaying cell")
    }
    func tableView(_ tableView: UITableView, didEndDisplayingHeaderView view: UIView, forSection section: Int) {
        print("didEndDisplayingHeaderView ")
    }
    func tableView(_ tableView: UITableView, didEndDisplayingFooterView view: UIView, forSection section: Int) {
        print("didEndDisplayingFooterView ")
    }
    func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        print("accessoryButtonTappedForRowWith ")
        print(indexPath.row)
    }
    func tableView(_ tableView: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        print("shouldHighlightRowAt ")
        return true
    }
    func tableView(_ tableView: UITableView, didHighlightRowAt indexPath: IndexPath) {
        print("didHighlightRowAt ")
    }
    func tableView(_ tableView: UITableView, didUnhighlightRowAt indexPath: IndexPath) {
        print("didUnhighlightRowAt ")
    }
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        print("didDeselectRowAt ")
    }
    func tableView(_ tableView: UITableView, willBeginEditingRowAt indexPath: IndexPath) {
        print("willBeginEditingRowAt")
    }
    func tableView(_ tableView: UITableView, didEndEditingRowAt indexPath: IndexPath?) {
        print("didEndEditingRowAt")
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        print("heightForFooterInSection ")
        return 50
        
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        print("heightForHeaderInSection ")
        return 50
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
         print("heightForRowAt")
        return 50
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        print("estimatedHeightForRowAt ")
        return 10
        
    }
    func tableView(_ tableView: UITableView, estimatedHeightForHeaderInSection section: Int) -> CGFloat {
        print("estimatedHeightForHeaderInSection ")
        return 50
       
    }
    func tableView(_ tableView: UITableView, estimatedHeightForFooterInSection section: Int) -> CGFloat {
        print("estimatedHeightForFooterInSection ")
        return 30
       
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        print("viewForHeaderInSection ")
         let Hview = UIView()
        //Hview.frame = CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 50)
        Hview.backgroundColor = UIColor.yellow
        
         let Hlabel = UILabel()
        Hlabel.frame = CGRect(x: 10, y: 0, width:100 , height: 50)
        Hlabel.textColor = UIColor.blue
        Hlabel.font = UIFont.boldSystemFont(ofSize: 20)
        if section == 0
        {
            Hlabel.text = "Animals"
        }
        else if section == 1
        {
            Hlabel.text = "Alphabet"
        }
        else
        {
            Hlabel.text = "Number"
        }
        // Hlabel.text = "Animal Alpabet Number"
         Hlabel.textAlignment = .center
         Hview.addSubview(Hlabel)

        let Hbtn = UIButton()
        Hbtn.frame = CGRect(x: 200, y: 10, width: 50, height: 28)
        Hbtn.setTitle("+", for: .normal)
        Hbtn.backgroundColor = UIColor.blue
        Hbtn.tag = 11
        Hbtn.addTarget(self, action: #selector(clickOnBtn), for: .touchUpInside)
        Hview.addSubview(Hbtn)

    return Hview
    }
    
    
    @IBAction func clickOnBtn(_ sender: Any) {
        //print("hii")
        let indexPath = IndexPath.init(row: (sender as AnyObject).tag, section: 0)
        print("select Row \(indexPath.row)")
        print("selected  \(animals[indexPath.row])")
    }

    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        //print("viewForFooterInSection ")
        let Fview = UIView()
        Fview.frame = CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 50)
        Fview.backgroundColor = UIColor.cyan
        //Fview.backgroundColor = UIColor.red
        let Flabel = UILabel()
        Flabel.frame = CGRect(x: 20, y: 0, width: 100, height: 50)
        Flabel.font = UIFont.boldSystemFont(ofSize: 18)
       // Flabel.text = "Footer 1 2 3"
        if section == 0
        {
            Flabel.text = "Footer 1"
        }
        else if section == 1
        {
            Flabel.text = "Footer 2"
        }
        else
        {
            Flabel.text = "Footer 3"
        }
        Flabel.textColor = UIColor.black
        Fview.addSubview(Flabel)
        
        return Fview

    }


//    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
//        print("leadingSwipeActionsConfigurationForRowAt")
//
//    }
//    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
//        print("trailingSwipeActionsConfigurationForRowAt")
//
//    }
    func tableView(_ tableView: UITableView, performAction action: Selector, forRowAt indexPath: IndexPath, withSender sender: Any?)
    {
        print("performAction")
    }
    func tableView(_ tableView: UITableView, canFocusRowAt indexPath: IndexPath) -> Bool {
        print("canFocusRowAt")
        return true
    }
    func tableView(_ tableView: UITableView, shouldUpdateFocusIn context: UITableViewFocusUpdateContext) -> Bool {
        print("shouldUpdateFocusIn")
       return true
    }
    func tableView(_ tableView: UITableView, didUpdateFocusIn context: UITableViewFocusUpdateContext, with coordinator: UIFocusAnimationCoordinator) {
        print("didUpdateFocusIn")
    }
    
    func tableView(_ tableView: UITableView, didBeginMultipleSelectionInteractionAt indexPath: IndexPath) {
        print("didBeginMultipleSelectionInteractionAt")
    }
    func tableViewDidEndMultipleSelectionInteraction(_ tableView: UITableView)
    {
        print("tableViewDidEndMultipleSelectionInteraction")
    }
}

class MyCustomTableViewCell: UITableViewCell {
    
    @IBOutlet weak var imageVIEW: UIImageView!
    @IBOutlet weak var LabelCell: UILabel!
    
}
